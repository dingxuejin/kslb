var qcloud = require('../../vendor/wafer2-client-sdk/index')
const config = require("../../config.js");
//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
    markers: [{ latitude: 31.4201900000, longitude: 121.0724900000 }],
    contant:{}
  },
  //事件处理函数
  bindViewTap: function () {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function (data) {
    var that = this
    //调用应用实例的方法获取全局数据
    // app.getUserInfo(function (userInfo) {
    //   //更新数据
    //   that.setData({
    //     userInfo: userInfo
    //   })
    // })

    qcloud.request({
      url: config.service.host+"/weapp/contant",
      success:function(res){
        that.setData({contant:res.data.data})
      }
    })
  },
  telUs: function () {
    wx.makePhoneCall({
      phoneNumber: '18706265789' //仅为示例，并非真实的电话号码
    })
  }
})