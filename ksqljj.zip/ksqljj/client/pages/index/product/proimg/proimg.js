Component({
  properties: {
    // 这里定义了innerText属性，属性值可以在组件使用时指定
    innerText: {
      type: String,
      value: 'default value',
    },
    product: {
      type: Array,
      value: []
    },
  },
  data: {
    // 这里是一些组件内部数据
    animationImg: [],
    animationData: {},
    topDataNewPro: [],
    timer: null
  },
  ready: function () {
    let that=this;
   setTimeout(function(){
     let top = [];
     let animate_nav = wx.createAnimation({
       duration: 600
     });
     top.length = that.data.product.length;
     top.fill(42);
     animate_nav.rotateZ(0).step();
     that.setData({
       topDataNewPro: top,
       animationData: animate_nav.export()
     });

     // 创建公共函数
     // 创建图片缩放
     that.changeImg = function (data) {
       let initAni;
       let initAni_img = wx.createAnimation({
         duration: 500
         // 图片还原时间
       });
       let animationContainer = [];
       let animate_img = wx.createAnimation({
         duration: 2000
         // 图片缩放时间
       });
       animationContainer.length = that.data.product.length;
       animate_img.scale(1).step();
       initAni_img.scale(1).step();
       initAni = animationContainer.slice();
       animationContainer.fill(animate_img.export());
       initAni.fill(initAni_img.export());
       animate_img.scale(1.2).step();
       // 图片放大1.2倍
       animationContainer[data.currentTarget.dataset.newproductnum] = animate_img.export();
       return { animationContainer: animationContainer, initAni: initAni }
       // 返回缩放动画animationContainer和还原动画initAni数组
     }

     // 创建图片标题移动
     that.translateImgTitle = function (data) {
       let top = [];
       let initTop;
       top.length = that.data.product.length;
       top.fill(42);
       // 标题向下偏移42vh
       initTop = top.slice();
       // 标题向下偏移3vh
       top[data.currentTarget.dataset.newproductnum] = 3;
       return { top: top, initTop: initTop }
       // 返回开始位置initTop和变化位置top
     }
   },500);
   
  },

  methods: {
    // 这里是一个自定义方法
    customMethod: function () { },
    changeTop: function (data) {
      let newScale = this.changeImg(data);
      let newTop = this.translateImgTitle(data);

      this.setData({ topDataNewPro: newTop.top, animationImg: newScale.animationContainer });
      if (this.data.timer !== null) {
        clearTimeout(this.data.timer);
      }
      this.data.timer = setTimeout(() => {
        this.setData({ topDataNewPro: newTop.initTop, animationImg: newScale.initAni });
      }, 5000)
    }
  }
})