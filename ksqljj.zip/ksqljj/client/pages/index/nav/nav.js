var qcloud = require('../../../vendor/wafer2-client-sdk/index')
const config = require("../../../config.js");
Component({
  properties: {
    // 这里定义了innerText属性，属性值可以在组件使用时指定
    innerText: {
      type: String,
      value: 'default value',
    }
  },
  data: {
    // 这里是一些组件内部数据
    animationData:{},
    nav: {}
  },
  ready:function(){
    let that=this;
    const requestTask = qcloud.request({
      url: config.service.host+ '/weapp/nav', //仅为示例，并非真实的接口地址
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        that.setData({ nav: res.data.data })
      }
    })
    setTimeout(function(){
      let animate_nav = wx.createAnimation({
        duration: 800
      });
      animate_nav.rotateY(0).step();
      that.setData({
        animationData: animate_nav.export()
      });
      
    },500)
    

  },
  methods: {
    // 这里是一个自定义方法
    customMethod: function () { }
  }
})