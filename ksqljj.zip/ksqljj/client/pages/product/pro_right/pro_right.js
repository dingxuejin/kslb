var qcloud = require('../../../vendor/wafer2-client-sdk/index')
const config = require("../../../config.js");
const { formatTime, showBusy, showSuccess, showModel }=require("../../../utils/util.js");
Component({
  properties: {
    // 这里定义了innerText属性，属性值可以在组件使用时指定
    sid: {
      type: Number,
      value: 0,
      observer :function(){
        this.product();
      }
    }
  },
  data: {
    // 这里是一些组件内部数据
    productAll:null
  },
  attached:function(){
    let that=this;
    showBusy("数据请求中...");
    this.product = function () {
      qcloud.request({
        url: config.service.host + "/weapp/product/all/" + that.data.sid,
        success: function (res) {
          showSuccess("请求成功！");
          that.setData({
            productAll:res.data.data
          });
        }
      })
    }
  },
  ready: function (){
 

},
  methods: {
    // 这里是一个自定义方法
    customMethod: function () { },
  }
})