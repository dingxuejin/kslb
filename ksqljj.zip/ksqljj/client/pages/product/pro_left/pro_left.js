var qcloud = require('../../../vendor/wafer2-client-sdk/index')
const config = require("../../../config.js");
Component({
  properties: {
    // 这里定义了innerText属性，属性值可以在组件使用时指定
    sid: {
      type: Number,
      value: 0,
      observer:function(){
        this.changeStyle()
      }
    },
    animate_title:{
      type:Array,
      value:[],
      observer: function () {
      }
    }

  },
  data: {
    // 这里是一些组件内部数据
    style: [],
    proNavTitle:[]
  },
  attached: function () {
    let that = this;
    qcloud.request({
      url: config.service.host + "/weapp/nav",
      success: function (res) {
        that.setData({
          proNavTitle: res.data.data
        })
      }
    })
    let style = this.data.style;
    style.length = this.data.proNavTitle.length;
    this.changeStyle=function(){
      let eventId = {
        sid: this.data.sid,
      }
      let style = this.data.style;
      style.fill(null);
      style[this.data.sid- 1] = "change";
      this.setData({ style: style });
      this.triggerEvent("myevent", eventId)
    }
  },
  ready:function(){
    let that=this;
    setTimeout(function(){
      let animateArr = [];
      animateArr.length = that.data.proNavTitle.length;
      animateArr.fill(null);
      animateArr = animateArr.map(function (val, i, arr) {
        let animate_title = wx.createAnimation({
          timingFunction: "linear",
          duration: 300,
          delay: (i * 300)
        })
        animate_title.translateX(0).step();
        return animate_title;
      })
      that.setData({
        animate_title: animateArr
      });
    },500)
    
  },
  methods: {
    // 这里是一个自定义方法
    customMethod: function () { },
    showProduct: function (data) {
      this.setData({sid: data.currentTarget.dataset.productnum})
    }

  }
})