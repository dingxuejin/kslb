var qcloud = require('../../vendor/wafer2-client-sdk/index')
const config = require("../../config.js");
Component({
  data:{
    address:""
  },
  ready:function(){
    let that=this;
    qcloud.request({
      url: config.service.host+"/weapp/address",
      success: function(res) {
        that.setData({address:res.data.data[0].address});
      },
      fail: function(res) {},
      complete: function(res) {},
    })
  }
})