const {DB,public} = require("../tools/initdb");
module.exports = {
    detailImg:async (ctx) => {
    let pid=ctx.params.pid;
    let row1 = await DB.raw("SELECT pimg FROM product WHERE  pid=?",pid)
    let row2 = await DB.raw("SELECT dimg FROM product,detail WHERE  pid=? AND detail.dnum=product.pnum",pid)
    let data =[row1[0][0].pimg];
    console.log(row2);
    if(row2[0].length>0){
        data = data.concat(row2[0][0].dimg.split(","));
    }
    data = data.map((val) => {
        val = public + val;
        return val;
    })

    ctx.state.data=data;
},
 detailPro: async (ctx) => {
    let pid=ctx.params.pid;
    let row = await DB.raw("SELECT * FROM product WHERE pid=?",pid)
    let newName = await DB.raw("SELECT ntitle FROM nav WHERE nid=?",row[0][0].pname);
    data = row[0].map((val) => {
        val.pname=newName[0][0].ntitle;
        val.pimg = public+ val.pimg;
        val.pcolor =public + val.pcolor;
        return val;
    })

    ctx.state.data=data;
}}