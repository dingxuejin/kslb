const {DB,public} = require("../tools/initdb");
module.exports = async (ctx) => {
    let row = await DB.raw("SELECT address FROM address")
    ctx.state.data=row[0];
}