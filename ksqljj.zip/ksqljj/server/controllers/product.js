const {DB,public} = require("../tools/initdb");
module.exports = async (ctx) => {
    let pid=ctx.params.pid
    let row1 = await DB.raw("SELECT nimg FROM nav WHERE nid=? ",pid)
    let row2 = await DB.raw("SELECT * FROM product WHERE isnew=1 AND pname=?",pid)
    let row3 = await DB.raw("SELECT * FROM product WHERE ishot=1 AND pname=?",pid)
    let row4 = await DB.raw("SELECT * FROM product WHERE isnew=0 AND ishot=0 AND pname=?",pid)
    let data = {};
    data.product=[];
    let data1 = row1[0].map((val) => {
        val.nimg =public + val.nimg;
        return val;
    })
    data.signboard = data1;
    if (row2[0].length>0) {
        let data2 = row2[0].map((val) => {
            val.pimg =public + val.pimg;
            val.pcolor =public + val.pcolor;
            return val;
        })
        let newdata = {productTitle: "最新产品", productImg: data2};
        data.product.push(newdata);
    }
    if (row3[0].length>0) {
        let data3 = row3[0].map((val) => {
            val.pimg =public + val.pimg;
            val.pcolor =public + val.pcolor;
            return val;
        })
        let newdata = {productTitle: "热门产品", productImg: data3};
        data.product.push(newdata);

    }
    if (row4[0].length>0) {
        let data4 = row4[0].map((val) => {
            val.pimg =public + val.pimg;
            val.pcolor =public + val.pcolor;
            return val;
        })
        let newdata = {productTitle: "全部产品", productImg: data4}
        data.product.push(newdata);
    }
    ctx.state.data=data;
}
