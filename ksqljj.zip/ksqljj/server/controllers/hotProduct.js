const {DB, public} = require("../tools/initdb");
module.exports = async (ctx) => {
        let row = await
        DB.raw("SELECT * FROM product WHERE ishot=1")
        let row1 = await
        DB.raw("SELECT ntitle FROM nav,product WHERE ishot=1 AND nav.nid=product.pname")
        row = row[0].map((val, i) => {
            val.pname = row1[0][i].ntitle;
            val.pimg = public + val.pimg;
            val.pcolor = public + val.pcolor;
            return val;
        })
        ctx.state.data = row;
    }





