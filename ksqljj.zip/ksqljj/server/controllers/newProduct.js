const {DB, public} = require("../tools/initdb");
module.exports = async (ctx) => {

        let row = await
        DB.raw("SELECT * FROM product WHERE isnew=1")
        let row1 = await
        DB.raw("SELECT ntitle FROM nav,product WHERE isnew=1 AND nav.nid=product.pname")
    console.log(222,row);
    console.log(223,row1);
    row = row[0].map((val, i) => {
            val.pname = row1[0][i].ntitle;
            val.pimg = public + val.pimg;
            val.pcolor = public + val.pcolor;
            return val;
        })
        ctx.state.data = row;
    }






