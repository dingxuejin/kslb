const {DB,public} = require("../tools/initdb");
module.exports = async (ctx) => {
    let row = await DB.raw("SELECT * FROM nav")
    row= row[0].map((val) => {
        val.nimg=public+val.nimg;
        return val;
    })
    console.log(row);
    ctx.state.data=row;
}