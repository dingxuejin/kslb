const {DB,public} = require("../tools/initdb");
module.exports = async (ctx) => {
    let row = await DB.raw("SELECT * FROM contant")
    ctx.state.data=row[0];
}