const {DB,public} = require("../tools/initdb");
module.exports = async (ctx) => {
    let row = await DB.raw("SELECT pid,bimg FROM banner,product WHERE banner.bnum=product.pnum")
    row= row[0].map((val) => {
        val.bimg = public + val.bimg;
        return val;
    })
    ctx.state.data=row;
}